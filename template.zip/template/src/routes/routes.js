import { Router } from 'express';

const router = Router();

//define routes

export default router;