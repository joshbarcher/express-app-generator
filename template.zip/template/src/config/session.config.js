export default {
    secret: "b798458a-9bb9-41c1-a44c-16868147874c",
    resave: false,
    saveUninitialized: true
}